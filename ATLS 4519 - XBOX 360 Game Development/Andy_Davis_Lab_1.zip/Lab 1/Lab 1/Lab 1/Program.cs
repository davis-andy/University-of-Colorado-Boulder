using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ATLS_4519_Lab1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, C#!!"); //Console writes 'Hello C#!!'
            Console.WriteLine("Hello Again"); //Console writes 'Hello Again'
            int x = 5;
            Console.WriteLine("Bon Jour!!");  //Console writes 'Bon Jour!!'
            int y = 4;
            Console.WriteLine("Guten Tag!!"); //Console writes 'Guten Tag!!'
            Console.WriteLine("Andy is the coolest person ever!!!"); //Console writes 'Andy is the coolest person ever!!!'
            Console.WriteLine("x = {0}; y = {1}", x, y);
            x = y;
            Console.WriteLine("x = {0}; y = {1}", x, y); //X and Y are now shown as equaling the integers shown above

            //I do not know any other code so I am not quite sure how to write anything yet so this is my project
        }
    }
}